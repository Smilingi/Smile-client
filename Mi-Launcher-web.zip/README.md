# Mi Launcher

## Instalación

1. Instala las dependencias:
```bash
npm install
```

2. Inicia el servidor de desarrollo:
```bash
npm run dev
```

3. Abre http://localhost:3000

## Deploy en Vercel

1. Sube este proyecto a GitHub
2. Ve a vercel.com y conecta tu repositorio
3. Click en "Deploy"

---
Creado con EXO Studios
